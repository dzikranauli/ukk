<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\AlbumController;
use App\Http\Controllers\FotoController;
use App\Http\Controllers\KomenController;
use App\Http\Controllers\LikeController;
use App\Models\Komen;
use App\Models\Userr;
use App\Models\Foto;
use App\Models\Album;
use App\Models\Like;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/login', function () {
    return view('login');
});

Route::get('/register', function () {
    return view('register');
});

Route::get('/tambahalbum', function () {
    return view('tambahalbum');
});


Route::get('/album', function () {
    return view('album');
});

Route::get('/isialbum', function () {
    return view('isialbum');
});

Route::get('/home1', function () {
    return view('home1');
});

// Route::get('/komentar', function () {
//     return view('komentar');
// });

Route::get('/home2',[FotoController::class, 'home']);

Route::get('/login',[LoginController::class, 'tampillog']);
Route::post('/login',[LoginController::class, 'login']);

Route::get('/register',[RegisterController::class, 'tampilreg']);
Route::post('/register',[RegisterController::class, 'Register']);

Route::get('/album',[AlbumController::class, 'album']);
Route::post('/album',[AlbumController::class, 'aksialbum']);

Route::get('/isialbum',[FotoController::class, 'foto']);
Route::get('/tambahfoto',[FotoController::class, 'fotoo']);
Route::post('/home2',[FotoController::class, 'aksifoto']);


Route::get('/komentar/{FotoID}',[KomenController::class, 'tampilKomentar']);
Route::post('/komentar/{FotoID}',[KomenController::class, 'aksiTambahKomentar']);
Route::get('/lihatkomentar/{FotoID}',[KomenController::class, 'lihatKomentar']);     

// Route::get('/home2',[LikeController::class,'lihatfoto']);
Route::get('/berilike/{FotoID}',[LikeController::class,'like']);