<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Isi Album</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f2f2f2;
    }

    .gallery {
        column-count: 3;
        column-gap: 15px;
        max-width: 1200px;
        margin: 20px auto;
    }

    .gallery img {
        width: 23rem;
        height: 20rem;
        margin-bottom: 15px;
        display: block;
        border-radius: 20%;
    }

    .background: #d1d5db;

    .height {
        height: 100vh;
    }

    .form {
        width: 50%;
        margin: top;
        position: relative;
    }

    .form .fa-search {
        position: absolute;
        top: 20px;
        left: 20px;
        color: #9ca3af;
    }

    .form span {
        position: absolute;
        right: 17px;
        top: 13px;
        padding: 2px;
        border-left: 1px solid #d1d5db;
    }

    .left-pan {
        padding-left: 7px;
    }

    .left-pan i {
        padding-left: 10px;
    }

    .form-input {
        height: 55px;
        text-indent: 33px;
        border-radius: 10px;
    }

    .form-input:focus {
        box-shadow: none;
        border: none;
    }

    h3,
    p {
        text-align: center;
    }

    .navbar {
        background-color: #b9936c;
    }

    button {
        background-color: #b9936c;
        border-radius: 20px;
        color: white;
        width: 10rem;
        height: 3rem;
    }

    button:hover {
        background-color: #dac292;
        color: black;
        transform: translateY(3px);
        box-shadow: none;
        animation: ani9 0.4s ease-in-out infinite alternate;
    }

    @keyframes ani9 {
        0% {
            transform: translateY(3px);
        }
        100% {
            transform: translateY(5px);
        }
    }

    .gallery {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
        max-width: 1200px;
        margin: 20px auto;
    }

    .photo {
        position: relative;
        overflow: hidden;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .photo img {
        width: 100%;
        height: auto;
        display: block;
    }

    .comments {
        background-color: #fff;
        border-radius: 0 0 8px 8px;
        padding: 10px;
    }

    .comment {
        margin-bottom: 10px;
        border-bottom: 1px solid #ddd;
        padding-bottom: 5px;
    }

    .comment-author {
        font-weight: bold;
        color: #4285f4;
    }

    .gallery {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
        max-width: 1200px;
        margin: 20px auto;
    }

    .photo {
        position: relative;
        overflow: hidden;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .photo img {
        width: 100%;
        height: auto;
        display: block;
    }

    .overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 77%;
        border-radius: 20%;
        background: rgb(252, 182, 193, 0.3);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .photo:hover .overlay {
        opacity: 1;
    }

    .overlay-content {
        text-align: center;
        color: #fff;
    }

    .overlay-content button {
        background-color: #d9ad7c;
        color: #fff;
        padding: 10px 15px border: none;
        border-radius: 20px;
        margin: 5px;
        cursor: pointer;
    }

    .overlay-content button:hover {
        background-color: #d9ad7c;
    }

    .gallery-row {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        justify-content: center;
    }

    .card {
        width: 100%;
        text-align: center;
        margin-bottom: 15px;
    }

    .car-img-top {
        width: 100%;
        height: auto;
        border-radius: 20%;
    }
</style>

</head>
<body style="background-color:#dac292">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/5.3/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/5.3/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/5.3/assets/img/favicons/safari-pinned-tab.svg" color="#712cf9">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon.ico">
<meta name="theme-color" content="#712cf9">

    
    <!-- Custom styles for this template -->
    <link href="headers.css" rel="stylesheet">
  </head>
  <body>

<nav class="navbar navbar-expand-lg p-3">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Gallery Photo</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    
      <div class=" collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto ">
        <li class="nav-item">
            <a class="nav-link mx-2 active" aria-current="page" href="album">Gallery</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mx-2 active" aria-current="page" href="home2">Logout</a>
          </li>
        </ul>
      </div>
    </div>
    </nav>
    </div>
<br>
   <center> <div class="form">
                <br>
                <a href="/tambahfoto">|<button type="tmbhalbum" href="tambahft">Tambah Foto</button></a>
</center>
<div class="container mt-4">
    <div class="gallery-row">
<?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card" style="width: 18rem;">
  <img src="<?php echo e($item->LokasiFile); ?>" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title" style="margin-bottom: 0;"><?php echo e($item->JudulFoto); ?></h5>
    <p class="card-text"><?php echo e($item->DeskripsiFoto); ?></p>
    <p class="card-text"><?php echo e($item->TanggalUnggah); ?></p>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script src="lightbox.js"></script>
</body>
</html>



</main>
</div>
<script src="/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    </body>
</html>


</body>
</html><?php /**PATH C:\Users\ZYREX\ukkwebgallery\resources\views/isialbum.blade.php ENDPATH**/ ?>