<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Userr;

class LoginController extends Controller
{
    

    public function tampillog(){
        return view('login');
}

public function login(Request $request)
{
   

    // Retrleve user data based on input
    $data = Userr::where('Username', $request->input('Username'))
          ->where('Password', $request->input('Password'))
          ->first();

    // Check if user exists
    if ($data === null) {
        return redirect('/login')->with('pesan','Username/ Password Salah !');
    }else{
        session()->put('user', $data);
        return redirect('/home2');
    }

}

public function logout()
{
    session()->flush();
    return redirect('/home');
}
}
