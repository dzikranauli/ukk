<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Foto;
use App\Models\Userr;
use App\Models\Album;
use App\Models\Like;

class FotoController extends Controller
{
    public function foto()
{
    if(session ('user') != null){
        $foto = Foto::all();
        return view('isialbum', ['foto' => $foto]);
    }else{
        return redirect('/login')->with('succes','Album berhasil ditambahkan');
    }
}

    public function home(){
        $foto = Foto ::all();  
        $like = Like::all();
    
        return view('home2', compact('foto','like'));
    }

public function fotoo(){
    
    return view('tambahfoto');
}

public function aksifoto(Request $request)
{
        $filefoto =$request->file('foto');
        $filefoto->move('folder',$filefoto->getClientOriginalName());

        $data = new Foto();
        $data -> JudulFoto = $request->input('JudulFoto');
        $data -> DeskripsiFoto = $request->input('DeskripsiFoto');
        $data -> TanggalUnggah = date('Y-m-d');
        $data -> LokasiFile = '/folder/'.$filefoto->getClientOriginalName();
        $data -> UserID = session ('user')->UserID;
        $data -> AlbumID =123;
        $data -> save();

        // dd($album);

        Session()->flash('succes','Foto Berhasil ditambahkan !');
        return redirect ('/home2');

    }
}
