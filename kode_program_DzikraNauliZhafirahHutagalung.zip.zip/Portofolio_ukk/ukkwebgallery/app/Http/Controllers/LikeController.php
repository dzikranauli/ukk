<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Facades\Auth;
use App\Models\Foto;
use App\Models\Userr;
use App\Models\Album;
use App\Models\Like;

class LikeController extends Controller
{
    public function lihatfoto($FotoID){
        if(session('user')){
            $foto = Foto ::all();  
            $like = Like::all();
    
            return view('home2', compact('foto','like'));
            
        }
    }
    
    public function like($FotoID)
    {
        $cek = Like::where('UserID',session('user')->UserID)
                    ->where('FotoID', $FotoID)
                    ->first();
    
            if(!$cek) {
            $data = new Like();
            $data->FotoID = $FotoID;
            $data->UserID = session('user')->UserID;
            $data->TanggalLike = date('Y-m-d'); 
            $data->save();
    
            return redirect()->back();
            }else{
                $cek->delete();
                return redirect()->back();
          }
    }
}
