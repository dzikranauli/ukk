<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Facades\Auth;
use App\Models\Userr;
use App\Models\Foto;
use App\Models\Komen;

class KomenController extends Controller
{
    public function tampilKomentar($FotoID)
    {
        if(session('user') != null) {
        $komen=Komen::all();
        return view('komentar', compact('komen', 'FotoID'));
    }else {
        return redirect('/login')->with('pesanbaru', 'Silahkan Login Terlebih Dahulu 1');
        }
    }

    public function lihatKomentar($FotoID)
    {
        if(session('user') != null) {
            $komen=Komen::all();
            return view('lihatkomentar', compact('komen', 'FotoID'));
        }else {
            return redirect('/login')->with('pesanbaru', 'Siahkan Login Terlebih Dahulu !');
        }
    }

    public function aksiTambahKomentar(Request $request,$FotoID)
    {
        $data = new Komen();
        $data -> IsiKomentar = $request->input('IsiKomentar');
        $data -> TanggalKomentar = date('Y-m-d');
        $data -> UserID = session('user')->UserID;
        $data -> FotoID = $FotoID;
        $data -> save();

        return redirect ('/home2')->with('pesanbaru', 'Komentar berhasil dikirim !');
    }
}