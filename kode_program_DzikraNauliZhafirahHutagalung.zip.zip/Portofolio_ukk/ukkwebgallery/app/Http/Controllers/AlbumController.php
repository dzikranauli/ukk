<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Userr;
use App\Models\Album;

class AlbumController extends Controller
{
    public function album() 
{
    if(session ('user') != null) {
        $album = Album::all();
        return view('album',['album' => $album]);
    }else{
        return redirect('/login')->with('succes', 'Album berhasil ditambahkan');
    }
}
public function aksialbum(Request $request)
{
    $data = new Album();
    $data->NamaAlbum = $request->input('NamaAlbum');
    $data->Deskripsi = $request->input('Deskripsi');
    $data->TanggalDibuat = date('Y-m-d');
    $data->UserID = session('user')->UserID;
    $data->save();

    return redirect('/album')->with('succes','Album berhasil ditambahkan!');
}
}
