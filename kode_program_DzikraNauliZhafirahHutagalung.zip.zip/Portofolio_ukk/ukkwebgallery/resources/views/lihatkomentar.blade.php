<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Isi Album</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        /* Body background color */
        body {
            background-color: #dac292; /* Light pink background color */
            margin: 0; /* Remove default margin */
            font-family: 'Arial', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        /* Style comment container */
        .comment-container {
            width: 100%;
            max-width: 500px; /* Set a maximum width for the comment container */
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #b9936c; /* Light pink border color */
            border-radius: 8px;
            background-color: #b9936c;
            box-shadow: 0 0 10px rgba(255, 105, 180, 0.2); /* Pink box shadow */
        }

        /* Style label for comment */
        .comment-container label {
            display: block;
            font-weight: bold;
            margin-bottom: 10px;
            color: black; /* Dark pink text color */
        }

        /* Style textarea in comment container */
        .comment-container textarea {
            width: 95%;
            padding: 10px; /* Increased padding */
            margin-bottom: 10px;
            border: 1px solid #b9936c; /* Light pink border color */
            border-radius: 8px;
            resize: none;
            background-color: #fff8f8; /* Lighter pink background color */
            color: #333; /* Dark text color */
            overflow-wrap: break-word; /* Breaks words to prevent content from exceeding the container */
        }

        /* Optional: Hover effect for comment container */
        .comment-container:hover {
            box-shadow: 0 0 15px rgba(255, 105, 180, 0.3); /* Darker pink box shadow on hover */
        }
    </style>
</head>

<body>

<div class="comment-container">
    @foreach($komen as $komentar)
   
        <label for="nama_album"><strong>Komentar:</strong></label>
        <textarea readonly>{{$komentar->IsiKomentar}}</textarea>
        @endforeach
</div>

</body>
</html>