<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bg.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Home</title>
    
    <style>
        body {
            background-color: ;
        }

        .gallery {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 16px;
            justify-content: center;
        }

        .gallery img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .container-fluid{
            background-color: #b9936c;
            height: 5rem;
        }
        
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">GALLERY PHOTO</a>
            <div class="search-container">
                <i class="fa fa-search"></i>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="text end">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="login">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register">Register</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <br>
    <br>
    <h2 style="font-family:Serif">
    <center><h2>SELAMAT DATANG</h2></center>
    <center><h2>Silahkan bagikan pengalaman anda di sini!</h2></center>
    <br>
    <br>

    <div class="gallery">
        <img src="7.jpg" alt="Foto 1">
        <img src="book.jpg" alt="Foto 2">
        <img src="10.jpg" alt="Foto 3">
        <img src="bunga.jpg" alt="Foto 4">
        <img src="9.jpg" alt="Foto 5">
        <img src="2.jpg" alt="Foto 6">
        <img src="4.jpg" alt="Foto 7">
        <img src="6.jpg" alt="Foto 8">
        <img src="3.jpg" alt="Foto 7">
        <img src="5.jpg" alt="Foto 7">
        <img src="paris2.jpg" alt="Foto 7">
        <img src="kue.jpg" alt="Foto 7">
        
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>
