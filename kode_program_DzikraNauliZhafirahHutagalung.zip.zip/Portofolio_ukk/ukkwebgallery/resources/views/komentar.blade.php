<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Isi Album</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background: #dac292;
    }

    .height {
        height: 100vh;
    }

    .navbar {
        background-color: #b9936c;
    }

    img {
        width: 20rem;
        height: 20rem;
    }

    form {
        max-width: 400px;
        margin: 0 auto;
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .form span {
        position: absolute;
        right: 17px;
        top: 13px;
        padding: 2px;
        border-left: 1px solid #d1d5db;
    }

    .left-pan {
        padding-left: 7px;
    }

    .left-pan i {
        padding-left: 10px;
    }

    .form-input {
        height: 45px;
        text-indent: 33px;
        border-radius: 20px;
    }

    .form-input:focus {
        box-shadow: none;
        border: none;
    }

    label {
        display: block;
        margin-bottom: 8px;
    }

/* Reset styling */
*   {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

/* Style comment container */
    .comment-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

/* Style comment form */
    .comment-form {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

/* Style textarea in comment form */
    .comment-form textarea {
        width: 300px;
        height: 150px;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 8px;
    }

    input {
        width: 100%;
        padding: 8px;
        margin-bottom: 16px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    button {
        background-color: #dac292;
        color: #fff;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    button:hover {
        background-color: #dac292;
        color: black;
        transform: translateY(3px);
        box-shadow: none;
        animation: ani9 0.4s ease-in-out infinite alternate;
    }

</style>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/5.3/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/5.3/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/5.3/assets/img/favicons/safari-pinned-tab.svg" color="#712cf9">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon.ico">
<meta name="theme-color" content="#712cf9">

    
    <!-- Custom styles for this template -->
    <link href="headers.css" rel="stylesheet">
  </head>
  <body>
    <div class="comment-container">
<form action="" method="POST" class="comment-form">
    @csrf
    <b><label for="komen">Komentar:</label></b>
    <textarea name="IsiKomentar" placeholder="Tambahkan Komentar"></textarea>
    <button type="submit" class="submit-button">Kirim</button>
</form> 
</main>
</div>
<script src="/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    </body>
</html>


</body>
</html>