<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        .gallery-container {
            max-width: 1200px;
            margin: 20px auto;
        }

        .gallery {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .card {
            width: calc(33.33% - 20px);
            margin-bottom: 20px;
            box-sizing: border-box;
            position: relative;
        }

        .button-group {
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .btn-icon,
        .btn-cmn {
            background: none;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            display: inline-block;
            vertical-align: middle;
            margin-right: 10px;
            border: none;
            color: #000; 
        }

        .card img {
            width: 100%;
            height: 80vh;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        h3 {
            margin: 10px 0;
            font-size: 1.5rem;
        }

        p {
            margin-bottom: 10px;
        }

        .height{

            height: 100vh;
        }

        .form{
            width: 50%;
            margin: top;
            position: relative;
        }

        .form .fa-search{

            position: absolute;
            top:20px;
            left: 20px;
            color: #9ca3af;

        }

        .form span{

            position: absolute;
            right: 17px;
            top: 13px;
            padding: 2px;
            border-left: 1px solid #d1d5db;

        }

        .left-pan{
            padding-left: 7px;
        }

        .left-pan i{
   
            padding-left: 10px;
        }

        .form-input{

            height: 55px;
            text-indent: 33px;
            border-radius: 10px;
        }

        .form-input:focus{

            box-shadow: none;
            border:none;
        }

        .navbar{
            background-color: #b9936c;
        }

        h3, p{
            text-align: center;
        }

        .btn-icon:hover{
            color: red;
        }

        button{
           background: #b9936c;
           border-radius: 5px;
        }

</style>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/5.3/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/5.3/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/5.3/assets/img/favicons/safari-pinned-tab.svg" color="#712cf9">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon.ico">
<meta name="theme-color" content="#712cf9">

    
    <!-- Custom styles for this template -->
    <link href="headers.css" rel="stylesheet">
  </head>
  <body style="background-color:#dac292">

<nav class="navbar navbar-expand-lg p-3">
      <b><a class="navbar-brand" href="#">GALLERY PHOTO</a></b>
      <div class=" collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto ">
          <li class="nav-item">
            <a class="nav-link mx-2 active" aria-current="page" href="album">Gallery</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mx-2 active" aria-current="page" href="home1">Logout</a>
          </li>
          </li>
          <a href="/"><button class="btn-nme">@ {{(Session()->get('user')->Username)}}</button></a>
          </li>
        </ul>
      </div>
    </div>
    </nav>
    </div>
    <br>
   <center>
<div class="gallery-container">
    <div class="gallery">
        @foreach($foto as $item)
        <div class="card">
            <img src="{{ $item->LokasiFile}}">
            <div>
            <button class="btn-icon">
            @if ($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $item->FotoID)->first())
                        <a href="/berilike/{{$item->FotoID}}">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart-fill" style=
                        "color:red;">
                    <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314"/>
                </svg>
                        </a>
                        {{ $like->where('FotoID', $item->FotoID)->count() }}

                        @else
                        <a href="/berilike/{{$item->FotoID}}">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart-fill" viewBox="0 0 16 16" >
                    <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314"/>
                </svg>
                        </a>
                        {{ $like->where('FotoID', $item->FotoID)->count() }}
                        @endif
              
            </button>
       
            <a href="/komentar/{{$item->FotoID}}">
                <button class="btn-cmn">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chat-dots" viewBox="0 0 16 16">
                        <path d="M5 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0m4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0m3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2"/>
                        <path d="m2.165 15.803.02-.004c1.83-.363 2.948-.842 3.468-1.105A9 9 0 0 0 8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6a10.4 10.4 0 0 1-.524 2.318l-.003.011a11 11 0 0 1-.244.637c-.079.186.074.394.273.362a22 22 0 0 0 .693-.125m.8-3.108a1 1 0 0 0-.287-.801C1.618 10.83 1 9.468 1 8c0-3.192 3.004-6 7-6s7 2.808 7 6-3.004 6-7 6a8 8 0 0 1-2.088-.272 1 1 0 0 0-.711.074c-.387.196-1.24.57-2.634.893a11 11 0 0 0 .398-2"/>
                    </svg>
                </button>
                <a href="/lihatkomentar/{{$item->FotoID}}">
                <button id="">lihat komentar</button>
            </button>
            </a>
        </div>
            <h3>{{ $item->JudulFoto }}</h3>
            <p>{{ $item->DeskripsiFoto }}</p>
        </div>
        @endforeach
        <!-- Add more cards if needed -->
    </div>
</div>


    <!-- <img src="bear2.jpg" alt="Image 3">
    <button class="btn-icon">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314"/>
</svg></button> 
<a href = "komentar" ><button class="btn-cmn">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chat-dots" viewBox="0 0 16 16">
  <path d="M5 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0m4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0m3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2"/>
  <path d="m2.165 15.803.02-.004c1.83-.363 2.948-.842 3.468-1.105A9 9 0 0 0 8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6a10.4 10.4 0 0 1-.524 2.318l-.003.011a11 11 0 0 1-.244.637c-.079.186.074.394.273.362a22 22 0 0 0 .693-.125m.8-3.108a1 1 0 0 0-.287-.801C1.618 10.83 1 9.468 1 8c0-3.192 3.004-6 7-6s7 2.808 7 6-3.004 6-7 6a8 8 0 0 1-2.088-.272 1 1 0 0 0-.711.074c-.387.196-1.24.57-2.634.893a11 11 0 0 0 .398-2"/>
</svg></button></a>
    <h3>BEAR</h3>
    <p>beruang adalah</p>
</svg></button></a> -->

<script src="lightbox.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<script>
    function toggleLike(button) {
        var likeCountElement = button.querySelector('.like-count');
        var likeCount = parseInt(likeCountElement.textContent);
        var isLiked = button.classList.toggle('liked');
        likeCountElement.textContent = isLiked ? likeCount + 1 : likeCount - 1;
    }

    function toggleCommentBox(button) {
        var commentBox = button.nextElementSibling;
        commentBox.classList.toggle('hidden');
    }

    function submitComment(button) {
        var inputElement = button.previousElementSibling;
        var commentText = inputElement.value;
        // Kirim komentar ke server atau lakukan tindakan yang sesuai
        console.log('Komentar:', commentText);
        inputElement.value = ''; // Mengosongkan input setelah mengirim komentar
    }

    function lihatKomentar() {
        // Implementasikan logika untuk menampilkan komentar di sini
        alert("Menampilkan komentar...");
        // Contoh: Ganti dengan logika sesuai kebutuhan
    }
</script>

</body>
</html>

</body>
</html>

</main>
</div>
<script src="/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>
</html>

</body>
</html>